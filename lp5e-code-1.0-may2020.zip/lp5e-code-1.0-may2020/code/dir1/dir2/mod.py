print('in mod.py')
z = 3
