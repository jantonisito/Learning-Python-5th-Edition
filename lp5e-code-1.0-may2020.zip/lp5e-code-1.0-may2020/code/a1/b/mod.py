print('mod.py')
