#x = 1
from __future__ import division
print(10 / 4)
