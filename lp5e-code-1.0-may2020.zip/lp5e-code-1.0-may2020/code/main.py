# code\main.py
#import string
from . import string
print(string)

